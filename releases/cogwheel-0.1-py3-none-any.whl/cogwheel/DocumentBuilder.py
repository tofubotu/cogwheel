# This is generic document builder
class DocumentBuilder:
    def __init__(self):
        self.build = True
