__author__ = "Leone Viru"
__version__ = "0.1"
__email__ = "leone.viru@gmail.com"
def init():
    """
    This is scriptwork for various
    """
    pass