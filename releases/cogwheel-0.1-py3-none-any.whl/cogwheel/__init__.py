__author__ = "Leone Viru"
__version__ = "0.2"
__email__ = "leone.viru@gmail.com"
def init():
    """
    This is scriptwork for various
    """
    pass